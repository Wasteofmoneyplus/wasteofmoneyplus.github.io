Hey! Thanks for using Wasteof.money+!

Now, be prepared, this may be a little more complicated than just hitting the "Add Extension" button in the Chrome Web Store.

(if you have an older version and want to upgrade, continue from step 4.)

1. In this zip file, you will see a folder named "Extension". 
Keep that folder in mind.

2. Now, type "chrome://extensions" in your address bar.
This will show you your extensions.

3. Turn on the "Developer mode" toggle.
You should see a menu appear at the top.

4. From said menu, click "Load unpacked".
Now, navigate into this zip file and choose the "Extension" folder.

And that's it! Go to wasteof.money/settings to see the changes!